import { Component, OnInit,Input, DoCheck } from '@angular/core';

@Component({
  selector: 'app-todolist-item',
  templateUrl: './todolist-item.component.html',
  styleUrls: ['./todolist-item.component.css']
})
export class TodolistItemComponent implements OnInit, DoCheck {
@Input() todo: any;
  constructor() { }

  ngOnInit() {
  }
  ngDoCheck() {
    console.log("UserListItemComponent-DoCheck");
  }
}
